#ifndef EOS_TOOLKIT_CONFIG_H
#define EOS_TOOLKIT_CONFIG_H



namespace EOS_Toolkit {

using real_t = double;

}

#endif
